﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using ConexionBD;

namespace Negocios
{
    
    public class Validaciones
    {
        ConexionValidacion cv = new ConexionValidacion();

        public Boolean validaringreso(string nick, string cont)
        {

            return cv.Valid(nick, cont);

        }


    }
}
