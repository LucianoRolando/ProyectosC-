﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using ConexionBD;

namespace Negocios
{
    
    public class ABM
    {
            Conexion con = new Conexion();

            public DataTable CrearTabla()
            {
                con.CrearDataTable();
                return con.table;
            }
            public DataTable Tabla()
            {
                con.ActualizarDataTable();
                return con.table;
            }
            public void Guardar(int idU, string Ap, string Am, string Nom, DateTime FR, string Co, string Ni)
            {
                int a = 0;
                foreach (DataRow row in con.table.Rows)
                {
                    if (Int32.Parse(row[0].ToString()) == idU)
                        a = 8;
                }
                if (a == 8)
                {
                    con.ModificarRegistro(idU, Ap, Am, Nom, FR, Co, Ni);
                }
                else
                    con.AgregarRegistro(idU, Ap, Am, Nom, FR, Co, Ni);
            }

            public void Borrar(int Id)
            {
                con.BorrarRegistro(Id);
            }

        public void CTBuscar()
        {
            con.CrearTBuscar();
           
        }
        public DataTable Buscar(String par)
        {
            con.BuscarRegistro(par);
            return con.tableBuscar;
        }

    }
      
}
