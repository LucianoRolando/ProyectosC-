﻿namespace InterfazUsuario
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.GrpIndividual = new System.Windows.Forms.GroupBox();
            this.txtNick = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtId_usuario = new System.Windows.Forms.TextBox();
            this.txtFecha_Registro = new System.Windows.Forms.TextBox();
            this.txtNombres = new System.Windows.Forms.TextBox();
            this.txtMaterno = new System.Windows.Forms.TextBox();
            this.txtPaterno = new System.Windows.Forms.TextBox();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.BtnEjecutar = new System.Windows.Forms.Button();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.GrpListado = new System.Windows.Forms.GroupBox();
            this.Grid = new System.Windows.Forms.DataGridView();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.BtnUpd = new System.Windows.Forms.Button();
            this.BtnDel = new System.Windows.Forms.Button();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.GrpIndividual.SuspendLayout();
            this.GrpListado.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Grid)).BeginInit();
            this.SuspendLayout();
            // 
            // GrpIndividual
            // 
            this.GrpIndividual.Controls.Add(this.txtNick);
            this.GrpIndividual.Controls.Add(this.txtPassword);
            this.GrpIndividual.Controls.Add(this.txtId_usuario);
            this.GrpIndividual.Controls.Add(this.txtFecha_Registro);
            this.GrpIndividual.Controls.Add(this.txtNombres);
            this.GrpIndividual.Controls.Add(this.txtMaterno);
            this.GrpIndividual.Controls.Add(this.txtPaterno);
            this.GrpIndividual.Controls.Add(this.BtnCancelar);
            this.GrpIndividual.Controls.Add(this.BtnEjecutar);
            this.GrpIndividual.Controls.Add(this.Label7);
            this.GrpIndividual.Controls.Add(this.Label4);
            this.GrpIndividual.Controls.Add(this.Label5);
            this.GrpIndividual.Controls.Add(this.Label6);
            this.GrpIndividual.Controls.Add(this.Label3);
            this.GrpIndividual.Controls.Add(this.Label2);
            this.GrpIndividual.Controls.Add(this.Label1);
            this.GrpIndividual.Location = new System.Drawing.Point(12, 210);
            this.GrpIndividual.Name = "GrpIndividual";
            this.GrpIndividual.Size = new System.Drawing.Size(515, 147);
            this.GrpIndividual.TabIndex = 3;
            this.GrpIndividual.TabStop = false;
            this.GrpIndividual.Text = "Datos del Usuario";
            // 
            // txtNick
            // 
            this.txtNick.Location = new System.Drawing.Point(365, 92);
            this.txtNick.Name = "txtNick";
            this.txtNick.Size = new System.Drawing.Size(111, 20);
            this.txtNick.TabIndex = 13;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(365, 69);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(111, 20);
            this.txtPassword.TabIndex = 11;
            // 
            // txtId_usuario
            // 
            this.txtId_usuario.BackColor = System.Drawing.SystemColors.Window;
            this.txtId_usuario.Location = new System.Drawing.Point(109, 15);
            this.txtId_usuario.Name = "txtId_usuario";
            this.txtId_usuario.Size = new System.Drawing.Size(108, 20);
            this.txtId_usuario.TabIndex = 1;
            this.txtId_usuario.TabStop = false;
            // 
            // txtFecha_Registro
            // 
            this.txtFecha_Registro.Location = new System.Drawing.Point(365, 44);
            this.txtFecha_Registro.Name = "txtFecha_Registro";
            this.txtFecha_Registro.ReadOnly = true;
            this.txtFecha_Registro.Size = new System.Drawing.Size(111, 20);
            this.txtFecha_Registro.TabIndex = 9;
            this.txtFecha_Registro.TabStop = false;
            // 
            // txtNombres
            // 
            this.txtNombres.Location = new System.Drawing.Point(109, 92);
            this.txtNombres.Name = "txtNombres";
            this.txtNombres.Size = new System.Drawing.Size(147, 20);
            this.txtNombres.TabIndex = 7;
            // 
            // txtMaterno
            // 
            this.txtMaterno.Location = new System.Drawing.Point(109, 69);
            this.txtMaterno.Name = "txtMaterno";
            this.txtMaterno.Size = new System.Drawing.Size(147, 20);
            this.txtMaterno.TabIndex = 5;
            // 
            // txtPaterno
            // 
            this.txtPaterno.Location = new System.Drawing.Point(109, 44);
            this.txtPaterno.Name = "txtPaterno";
            this.txtPaterno.Size = new System.Drawing.Size(147, 20);
            this.txtPaterno.TabIndex = 3;
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.Location = new System.Drawing.Point(255, 118);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(118, 21);
            this.BtnCancelar.TabIndex = 15;
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.UseVisualStyleBackColor = true;
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // BtnEjecutar
            // 
            this.BtnEjecutar.Location = new System.Drawing.Point(136, 118);
            this.BtnEjecutar.Name = "BtnEjecutar";
            this.BtnEjecutar.Size = new System.Drawing.Size(118, 21);
            this.BtnEjecutar.TabIndex = 14;
            this.BtnEjecutar.Text = "Guardar";
            this.BtnEjecutar.UseVisualStyleBackColor = true;
            this.BtnEjecutar.Click += new System.EventHandler(this.BtnEjecutar_Click);
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(35, 95);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(49, 13);
            this.Label7.TabIndex = 6;
            this.Label7.Text = "Nombres";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(276, 95);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(29, 13);
            this.Label4.TabIndex = 12;
            this.Label4.Text = "Nick";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(276, 72);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(53, 13);
            this.Label5.TabIndex = 10;
            this.Label5.Text = "Password";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(276, 46);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(79, 13);
            this.Label6.TabIndex = 8;
            this.Label6.Text = "Fecha Registro";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(35, 72);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(65, 13);
            this.Label3.TabIndex = 4;
            this.Label3.Text = "Ap. Materno";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(35, 46);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(63, 13);
            this.Label2.TabIndex = 2;
            this.Label2.Text = "Ap. Paterno";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(37, 22);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(58, 13);
            this.Label1.TabIndex = 0;
            this.Label1.Text = "Id. Usuario";
            // 
            // GrpListado
            // 
            this.GrpListado.Controls.Add(this.btnBuscar);
            this.GrpListado.Controls.Add(this.Grid);
            this.GrpListado.Controls.Add(this.BtnAdd);
            this.GrpListado.Controls.Add(this.BtnUpd);
            this.GrpListado.Controls.Add(this.BtnDel);
            this.GrpListado.Location = new System.Drawing.Point(12, 12);
            this.GrpListado.Name = "GrpListado";
            this.GrpListado.Size = new System.Drawing.Size(517, 192);
            this.GrpListado.TabIndex = 2;
            this.GrpListado.TabStop = false;
            this.GrpListado.Text = "Listado de Usuarios";
            // 
            // Grid
            // 
            this.Grid.AllowUserToAddRows = false;
            this.Grid.AllowUserToDeleteRows = false;
            this.Grid.AllowUserToResizeRows = false;
            this.Grid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Grid.BackgroundColor = System.Drawing.SystemColors.Window;
            this.Grid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Grid.EnableHeadersVisualStyles = false;
            this.Grid.GridColor = System.Drawing.Color.Silver;
            this.Grid.Location = new System.Drawing.Point(6, 16);
            this.Grid.MultiSelect = false;
            this.Grid.Name = "Grid";
            this.Grid.ReadOnly = true;
            this.Grid.RowHeadersVisible = false;
            this.Grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Grid.Size = new System.Drawing.Size(435, 169);
            this.Grid.TabIndex = 0;
            // 
            // BtnAdd
            // 
            this.BtnAdd.Location = new System.Drawing.Point(447, 16);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(61, 23);
            this.BtnAdd.TabIndex = 1;
            this.BtnAdd.Text = "Nuevo";
            this.BtnAdd.UseVisualStyleBackColor = true;
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // BtnUpd
            // 
            this.BtnUpd.Location = new System.Drawing.Point(447, 45);
            this.BtnUpd.Name = "BtnUpd";
            this.BtnUpd.Size = new System.Drawing.Size(61, 23);
            this.BtnUpd.TabIndex = 2;
            this.BtnUpd.Text = "Modificar";
            this.BtnUpd.UseVisualStyleBackColor = true;
            this.BtnUpd.Click += new System.EventHandler(this.BtnUpd_Click);
            // 
            // BtnDel
            // 
            this.BtnDel.Location = new System.Drawing.Point(447, 74);
            this.BtnDel.Name = "BtnDel";
            this.BtnDel.Size = new System.Drawing.Size(61, 23);
            this.BtnDel.TabIndex = 3;
            this.BtnDel.Text = "Eliminar";
            this.BtnDel.UseVisualStyleBackColor = true;
            this.BtnDel.Click += new System.EventHandler(this.BtnDel_Click);
            // 
            // btnBuscar
            // 
            this.btnBuscar.Location = new System.Drawing.Point(447, 103);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(61, 23);
            this.btnBuscar.TabIndex = 4;
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.BtnBuscar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoScrollMinSize = new System.Drawing.Size(530, 370);
            this.ClientSize = new System.Drawing.Size(544, 370);
            this.Controls.Add(this.GrpIndividual);
            this.Controls.Add(this.GrpListado);
            this.Enabled = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Activated += new System.EventHandler(this.Form1_Activated);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.GrpIndividual.ResumeLayout(false);
            this.GrpIndividual.PerformLayout();
            this.GrpListado.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Grid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.GroupBox GrpIndividual;
        internal System.Windows.Forms.TextBox txtNick;
        internal System.Windows.Forms.TextBox txtPassword;
        internal System.Windows.Forms.TextBox txtId_usuario;
        internal System.Windows.Forms.TextBox txtFecha_Registro;
        internal System.Windows.Forms.TextBox txtNombres;
        internal System.Windows.Forms.TextBox txtMaterno;
        internal System.Windows.Forms.TextBox txtPaterno;
        internal System.Windows.Forms.Button BtnCancelar;
        internal System.Windows.Forms.Button BtnEjecutar;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.GroupBox GrpListado;
        protected System.Windows.Forms.DataGridView Grid;
        internal System.Windows.Forms.Button BtnAdd;
        internal System.Windows.Forms.Button BtnUpd;
        internal System.Windows.Forms.Button BtnDel;
        internal System.Windows.Forms.Button btnBuscar;
    }
}

