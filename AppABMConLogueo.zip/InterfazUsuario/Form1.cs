﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Negocios;

namespace InterfazUsuario
{
    public partial class Form1 : Form
    {
        Form2 frm2 = new Form2();
       
        ABM Abm = new ABM();
        DateTime fechaactual = DateTime.Now;
        DateTime fecha = new DateTime();
        
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnEjecutar_Click(object sender, EventArgs e)
        {
            if (txtId_usuario.Text == "" || txtPaterno.Text == "" || txtMaterno.Text == "" || txtNombres.Text == "" || txtFecha_Registro.Text == "" || txtPassword.Text == "" || txtNick.Text == "")
                MessageBox.Show("Debe completar completar todos los campos");
            else
            {
                Abm.Guardar(Int32.Parse(txtId_usuario.Text), txtPaterno.Text, txtMaterno.Text, txtNombres.Text, fecha, txtPassword.Text, txtNick.Text);

                foreach (Control x in GrpIndividual.Controls)
                {
                    if (x is TextBox)
                        x.Text = "";
                }
                Grid.DataSource = Abm.Tabla();
                Grid.ClearSelection();
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            foreach (Control x in GrpIndividual.Controls)
            {
                if (x is TextBox)
                    x.Text = "";
            }
            txtFecha_Registro.Text = fechaactual.ToShortDateString();
            fecha = fechaactual;
            Grid.ClearSelection();
        }

        private void BtnUpd_Click(object sender, EventArgs e)
        {
            if (this.Grid.CurrentRow.Selected)
            {
                fecha = Convert.ToDateTime(this.Grid.CurrentRow.Cells[4].Value);
                txtId_usuario.Text = this.Grid.CurrentRow.Cells[0].Value.ToString();
                txtPaterno.Text = this.Grid.CurrentRow.Cells[1].Value.ToString();
                txtMaterno.Text = this.Grid.CurrentRow.Cells[2].Value.ToString();
                txtNombres.Text = this.Grid.CurrentRow.Cells[3].Value.ToString();
                txtFecha_Registro.Text = fecha.ToShortDateString();
                txtPassword.Text = this.Grid.CurrentRow.Cells[5].Value.ToString();
                txtNick.Text = this.Grid.CurrentRow.Cells[6].Value.ToString();
            }
        }

        private void BtnDel_Click(object sender, EventArgs e)
        {
            if (this.Grid.CurrentRow.Selected)
            {
                Abm.Borrar(Int32.Parse(this.Grid.CurrentRow.Cells[0].Value.ToString()));
            }
            Grid.DataSource = Abm.Tabla();
            Grid.ClearSelection();
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            foreach (Control x in GrpIndividual.Controls)
            {
                if (x is TextBox)
                    x.Text = "";
            }

            Grid.ClearSelection();
        }
        private void Form1_Shown(object sender, EventArgs e)
        {
            frm2.Show();
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            if (frm2.Disposing)
            {
                this.Enabled = true;
                Grid.DataSource = Abm.CrearTabla();
                Grid.ClearSelection();
            }
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            Form3 frm3 = new Form3();
            Grid.ClearSelection();
            frm3.Show();
        }
    }
}
