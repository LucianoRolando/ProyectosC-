﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Negocios;

namespace InterfazUsuario
{
    public partial class Form2 : Form
    {
       
        Validaciones val = new Validaciones();
        
        public Form2()
        {
            InitializeComponent();
        }

        private void BtnAceptar_Click(object sender, EventArgs e)
        {
           
            if(val.validaringreso(txtNick.Text, txtPassword.Text)==true)
            {
                Dispose();
            }
            else
                MessageBox.Show("Datos Incorrectos");

        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
