﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
namespace ConexionBD
{
    public class Conexion
    {
        SqlConnection conexion = new SqlConnection("data source=LUCIANO-PC\\SQLEXPRESS; initial catalog=PRUEBA; integrated security=sspi");
        public DataTable table = new DataTable();
        public DataTable tableBuscar = new DataTable();

        

        public void CrearDataTable()
        {
            table.Columns.Add("IdUsuario", System.Type.GetType("System.Int32"));
            table.Columns.Add("A Paterno", System.Type.GetType("System.String"));
            table.Columns.Add("A Materno", System.Type.GetType("System.String"));
            table.Columns.Add("Nombre", System.Type.GetType("System.String"));
            table.Columns.Add("FechaRegistro", System.Type.GetType("System.DateTime"));
            table.Columns.Add("Contraseña", System.Type.GetType("System.String"));
            table.Columns.Add("Nick", System.Type.GetType("System.String"));
            ActualizarDataTable();
        }
        public void ActualizarDataTable()
        {
            try
            {
                table.Clear();
                SqlCommand comando = new SqlCommand("select * from tbUsuario order by id_usuario asc;", conexion);
                SqlDataReader lector;
                comando.CommandType = System.Data.CommandType.Text;
                conexion.Open();
                lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    table.Rows.Add(new object[] { lector.GetInt32(0), lector.GetString(1), lector.GetString(2), lector.GetString(3), lector.GetDateTime(4), lector.GetString(5), lector.GetString(6) });
                }
            }
            catch (SqlException ex) { throw ex; }
            finally { conexion.Close(); }
        }
        public void AgregarRegistro(int idU, string Apat, string Amat, string nom, DateTime fech, string cont, string nick)
        {
            try
            {
                conexion.Open();
                SqlCommand comando = new SqlCommand("INSERT INTO tbUsuario ( id_usuario,paterno,materno,nombres,fecha_registro,password,nick) VALUES ('" + idU + "',@Apat,@Amat,@nom,@fech,@cont, '" + nick + "');", conexion);
                comando.CommandType = CommandType.Text;

                //comando.Parameters.AddWithValue("@idu", idU);
                comando.Parameters.AddWithValue("@Apat", Apat);
                comando.Parameters.AddWithValue("@Amat", Amat);
                comando.Parameters.AddWithValue("@nom", nom);
                comando.Parameters.AddWithValue("@fech", fech);
                comando.Parameters.AddWithValue("@cont", cont);
                //comando.Parameters.AddWithValue("@nick", nick);

                comando.ExecuteNonQuery();
            }
            catch { }
            finally { conexion.Close(); }
        }
        public void BorrarRegistro(int ID)
        {
            conexion.Open();
            SqlCommand comando = new SqlCommand("DELETE FROM tbUsuario WHERE id_usuario=@Id", conexion);

            comando.CommandType = CommandType.Text;
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();

            conexion.Close();
        }
        public void ModificarRegistro(int idU, string Apat, string Amat, string nom, DateTime fech, string cont, string nick)
        {
            try
            {
                conexion.Open();
                SqlCommand comando = new SqlCommand("UPDATE tbUsuario SET paterno=@Apat, materno = @Amat, nombres = @nom, fecha_registro=@fech,password=@cont,nick=@nick WHERE id_usuario =@idu ", conexion);
                comando.CommandType = CommandType.Text;

                comando.Parameters.AddWithValue("@idu", idU);
                comando.Parameters.AddWithValue("@Apat", Apat);
                comando.Parameters.AddWithValue("@Amat", Amat);
                comando.Parameters.AddWithValue("@nom", nom);
                comando.Parameters.AddWithValue("@fech", fech);
                comando.Parameters.AddWithValue("@cont", cont);
                comando.Parameters.AddWithValue("@nick", nick);
                comando.ExecuteNonQuery();
            }
            catch { }
            finally { conexion.Close(); }
        }
        public void CrearTBuscar()
        {

            tableBuscar.Columns.Add("IdUsuario", System.Type.GetType("System.Int32"));
            tableBuscar.Columns.Add("APaterno", System.Type.GetType("System.String"));
            tableBuscar.Columns.Add("AMaterno", System.Type.GetType("System.String"));
            tableBuscar.Columns.Add("Nombre", System.Type.GetType("System.String"));
            tableBuscar.Columns.Add("FechaRegistro", System.Type.GetType("System.DateTime"));
            tableBuscar.Columns.Add("Contraseña", System.Type.GetType("System.String"));
            tableBuscar.Columns.Add("Nick", System.Type.GetType("System.String"));

        }
        public void BuscarRegistro(string parametro)
        {
                tableBuscar.Clear();
            conexion.Open();
            SqlCommand comando = new SqlCommand("select * from tbUsuario where nick like @Par+'%' or nombres like @Par+'%' or paterno like @Par+'%' or materno like @Par+'%';", conexion);
            comando.CommandType = System.Data.CommandType.Text;
            comando.Parameters.AddWithValue("@Par", parametro);
            comando.ExecuteNonQuery();

            SqlDataReader lector;
            lector = comando.ExecuteReader();
            while (lector.Read())
            {
                tableBuscar.Rows.Add(new object[] { lector.GetInt32(0), lector.GetString(1), lector.GetString(2), lector.GetString(3), lector.GetDateTime(4), lector.GetString(5), lector.GetString(6) });
            }
            conexion.Close();



        }
    }
}