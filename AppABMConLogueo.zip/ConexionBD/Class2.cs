﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace ConexionBD
{
    public class ConexionValidacion
    {
        SqlConnection conexion = new SqlConnection("data source=LUCIANO-PC\\SQLEXPRESS; initial catalog=PRUEBA; integrated security=sspi");

        public Boolean Valid(string ni, string co)
        {
            Boolean a = false;
            SqlCommand comando = new SqlCommand("select nick,password from tbUsuario", conexion);
            conexion.Open();
            SqlDataReader lector = comando.ExecuteReader();
            while (lector.Read())
            {
                if (lector.GetString(0) == ni && lector.GetString(1) == co)
                    a = true;
            }
            conexion.Close();
            return a;
        }
    }
}
