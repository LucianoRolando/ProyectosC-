﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace TP_Opcional_Rolando_Luciano
{
    class Program
    {
        static void Main(string[] args)
        {

            Log.Escribir("Inicia el programa");

            Log.Escribir("Ejecuta el programa");

            Log.Escribir("Finaliza el programa");
            
            Console.ReadLine();

        }

    }
}
