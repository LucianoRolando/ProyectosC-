﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TP_Opcional_Rolando_Luciano
{
   
    static class Log
    {     
       static string salida = Properties.Settings.Default.Salida;

               public static void Escribir(String texto)
                {
                    StreamWriter ficheroappend;
                   
                    switch (salida)
                    {
                        case "Consola":
                            Console.WriteLine(DateTime.Now.ToString("  dd/MM/yyyy hh:mm:ss - ") + texto);
                            break;

                        case "Archivo":
                            ficheroappend = File.AppendText("C:\\Users\\Luciano\\Desktop\\log.txt");
                            ficheroappend.WriteLine(DateTime.Now.ToString("  dd/MM/yyyy hh:mm:ss - ") + texto);
                            ficheroappend.Close();
                            break;

                        default:
                            Console.WriteLine("Default case");
                            break;
                    }
                }
    }
}
