﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP_N_8_RolandoLuciano
{
    public partial class Form1 : Form
    {
        List<Libro> Listalibro = new List<Libro>();
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnIngresar_Click(object sender, EventArgs e)
        {
            Libro nuevolibro = new Libro();
            nuevolibro.precio = Convert.ToDouble(txbPrecio.Text);

            try
            {
                nuevolibro.nombre = tbxNombre.Text;
                nuevolibro.autor = tbxAutor.Text;
                nuevolibro.genero = cbxGenero.Text;
                nuevolibro.paginas = Convert.ToInt32(tbxPaginas.Text);
                nuevolibro.importado = chbImportado.Checked;

                listBox1.Items.Clear();
                Listalibro.Add(nuevolibro);

                foreach (Libro item in Listalibro)
                {
                    string Importacion = (item.importado == true) ? "Importado" : "Nacional";
                    listBox1.Items.Add(item.nombre + " - " + item.autor + " - " + item.genero + " - " + item.paginas + " - " + Importacion + " - " + item.precio);
                }

                tbxNombre.Clear();
                tbxAutor.Clear();
                cbxGenero.Text = null;
                tbxPaginas.Clear();
                chbImportado.Checked = false;
                txbPrecio.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\nEl valor de Paginas no es un valor numerico valido", "Error");
            }
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            tbxNombre.Clear();
            tbxAutor.Clear();
            cbxGenero.Text = null;
            tbxPaginas.Clear();
            chbImportado.Checked = false;
            txbPrecio.Clear();
        }
    }
}
