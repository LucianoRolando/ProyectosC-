﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP_N_8_RolandoLuciano
{
    public class Libro
    {
        public string nombre;
        public string autor;
        public string genero;
        public int paginas;
        public Boolean importado;
        public double precio;
    }
}
