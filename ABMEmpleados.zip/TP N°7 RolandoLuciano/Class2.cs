﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace TP_N_7_RolandoLuciano
{
    class Conexion
    {
        SqlConnection conexion = new SqlConnection("data source=LUCIANO-PC\\SQLEXPRESS; initial catalog=EMPLEADOS_DB; integrated security=sspi");

        public List<Empleado> Empleadoslista()
        {
            List<Empleado> Empleados = new List<Empleado>();

            SqlCommand comando = new SqlCommand("select * from dbo.Empleados ORDER BY [Id] ASC;", conexion);
            SqlDataReader lector;

            comando.CommandType = System.Data.CommandType.Text;

            conexion.Open();

            lector = comando.ExecuteReader();
            while (lector.Read())
            {
                Empleado aux = new Empleado();

                aux.Id = lector.GetInt32(0);
                aux.NombreCompleto = lector.GetString(1);
                aux.DNI = lector.GetString(2);
                aux.Edad = lector.GetInt32(3);                                             
                aux.Casado = lector.GetBoolean(4);
                aux.Salario = lector.GetDecimal(5);

                Empleados.Add(aux);
            }
            conexion.Close();

            return Empleados;
        }

        public void Agregar(string nombre, string DNI,  int Edad, Boolean Casado, decimal Salario)
        {
            conexion.Open();
            SqlCommand command = new SqlCommand("INSERT INTO Empleados ( NombreCompleto,DNI,Edad,Casado,Salario) VALUES (@Nombre,@DNI, @Edad, @Casado,@Salario);", conexion);
            command.CommandType = CommandType.Text;

            command.Parameters.AddWithValue("@Nombre", nombre);
            command.Parameters.AddWithValue("@DNI", DNI);
            command.Parameters.AddWithValue("@Edad", Edad);
            command.Parameters.AddWithValue("@Casado", Casado);
            command.Parameters.AddWithValue("@Salario", Salario);

            command.ExecuteNonQuery();
            
            conexion.Close();
        }

    }
}
