﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP_N_7_RolandoLuciano
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Conexion conexion = new Conexion();
        private void Form1_Load(object sender, EventArgs e)
        {         
            dataGridView1.DataSource = conexion.Empleadoslista();
        }

        private void Agregar_Click(object sender, EventArgs e)
        {
            string Nombre = tbxNombre.Text;
            string DNI = tbxDNI.Text;
            int Edad = Int32.Parse(tbxEdad.Text);
            Boolean Casado = cbxCasado.Checked;
            decimal Salario = decimal.Parse(tbxSalario.Text);

            conexion.Agregar(Nombre, DNI, Edad, Casado, Salario);

            tbxNombre.Text = "";
            tbxDNI.Text = "";
            cbxCasado.Checked = false;
            tbxEdad.Text = "";
            tbxSalario.Text = "";

            dataGridView1.DataSource = conexion.Empleadoslista();
        }
    }
}
