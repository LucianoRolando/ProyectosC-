﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP_N_7_RolandoLuciano
{
    class Empleado
    {
        public int Id { get; set; }
        public string NombreCompleto { get; set; }
        public string DNI { get; set; }
        public int Edad { get; set; }
        public Boolean Casado { get; set; }
        public decimal Salario { get; set; }

    }
}
